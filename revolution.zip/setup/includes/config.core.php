<?php
if (!defined('MODX_CORE_PATH')) define('MODX_CORE_PATH', MODX_INSTALL_PATH . 'core/');
if (!defined('MODX_CONFIG_KEY')) define('MODX_CONFIG_KEY', 'config');
define ('MODX_SETUP_KEY', '@git@');

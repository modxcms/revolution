<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '203f9cce81497f335de8ec5b1f8eaaa2',
      'native_key' => 'core',
      'filename' => 'modNamespace/085620ab4c8466ef1aad08f87c9119a8.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => '1f0c6de5ec7d7fcb948071d5f814c477',
      'native_key' => 1,
      'filename' => 'modWorkspace/9dbb471434c872d9243c4ac6f6257850.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => '79f127c67789381a8a3bc3e5db5a3e04',
      'native_key' => 1,
      'filename' => 'modTransportProvider/e88d79d19814aad41edae9fc43fabdec.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '559625b9224f54431297bb44d532a34f',
      'native_key' => 1,
      'filename' => 'modAction/5b5e5284653a8c86c5591c21509d55ae.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '3aa895b21db28fa36c795f378e719590',
      'native_key' => 3,
      'filename' => 'modAction/04e58bad6c33803e7fd1db8ee0c97dd9.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '45be5dd97cf2ca2f9f5ac4e5ba2bb44c',
      'native_key' => 5,
      'filename' => 'modAction/9d8417b7b89b09127aac551f28feaca5.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '6f5201e3401ea7dc63a49213776602cd',
      'native_key' => 7,
      'filename' => 'modAction/b960afac3257b02af9e855380ee03f9f.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '1406fd47a0526af6408e03bbe7d7ac8c',
      'native_key' => 8,
      'filename' => 'modAction/082c653c3a8da6997a6bbcce566121d4.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'ba85794ff0d9aa5762c00af9db35a815',
      'native_key' => 9,
      'filename' => 'modAction/17829a11a652ae538c056c4186a6e71a.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '184efe01f49eef88e1469bcca4f3170f',
      'native_key' => 10,
      'filename' => 'modAction/fffd8a1cbece17527bf0b544d218f45b.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '11edaccd81e4c86fd0d809a6a25f84e0',
      'native_key' => 11,
      'filename' => 'modAction/8606435afe69a91aea6454d8ebe286e2.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '9a3ca29f5ec0cfd21349449be74d5410',
      'native_key' => 12,
      'filename' => 'modAction/a1442b5adec46e726026427a3c013a16.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'f7ad7342950677c5c0999e4b81fa7eec',
      'native_key' => 13,
      'filename' => 'modAction/198e175a8354f3511bd57eea05e2939c.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'fea73fe0b38a076e7b01f108c7b6dca8',
      'native_key' => 20,
      'filename' => 'modAction/15526cfb124affea86a92b132ddf3e7d.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'f962775164d04c6590e6168b41f19c96',
      'native_key' => 21,
      'filename' => 'modAction/cfccca33ea220cc9c2cd4a3f0d26c8d8.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '1945b7070949ca82dda2b288efa7feff',
      'native_key' => 22,
      'filename' => 'modAction/8131f8d21541a8420d6821eae883c9d7.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'e576278744dd95a7cc764c7d6a94ffdb',
      'native_key' => 25,
      'filename' => 'modAction/db902a7ceeb69b4943b86f8b323c8be1.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'ebda3f645676f0d95ba9a1104a4e7a53',
      'native_key' => 26,
      'filename' => 'modAction/e8d12489aaa6edfe0a7c8e43a30de8fd.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '1ae49eaf6a98660c80f0f85d1d2f215e',
      'native_key' => 27,
      'filename' => 'modAction/9b6c9bd6c69bca81f69cbb0b620209ec.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '6701ab1732528bbca27e9a50f0369414',
      'native_key' => 28,
      'filename' => 'modAction/4b45ea873f8ccdab07fadf82071b5bf8.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'ead4219a2cd8cb2c055620b3a94689ba',
      'native_key' => 29,
      'filename' => 'modAction/e5b4dc7923effb7b617c8ae886e2909b.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'bcd8bab22a510c5006264563108f6c12',
      'native_key' => 30,
      'filename' => 'modAction/21713fba84423232e6b89ee4dd9ac32b.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '09eb0fbcd4bd2ab9266e92e012ca2396',
      'native_key' => 31,
      'filename' => 'modAction/4a18c756ac39bda08773f55cd2dbb4c0.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '014352a51c1ea889558b9183a7f2fdaf',
      'native_key' => 32,
      'filename' => 'modAction/5e7d0e3e803d23cb57c1f88274d7bf62.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '36dfd740c279d9cdafd1b20f5c39ab45',
      'native_key' => 33,
      'filename' => 'modAction/776820db0643c5c4b7487a61cd88275b.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'd326e7f03ba81111237bc6c7b71b52e7',
      'native_key' => 34,
      'filename' => 'modAction/f9e1b3c44524ae4438db6ce3da0ba3e5.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '711accf32960a4083b7fb39fe342e480',
      'native_key' => 35,
      'filename' => 'modAction/09eb1438386e12af252cbcb81007fd20.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '161f6f58ce9d1c1f1f17fdd88f51dff2',
      'native_key' => 36,
      'filename' => 'modAction/0b3e7368e8db4dd99826aadf3425e6f3.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '82b59696dedc9644519ef4f9c7464997',
      'native_key' => 38,
      'filename' => 'modAction/6e1208b2233acc8498207ce74e01ab04.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '5b381d99f99fad0942859eb07166755d',
      'native_key' => 39,
      'filename' => 'modAction/14fce02efe2ae9a4e6e24da833b3f3e6.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'ace757b08419985b81713542d5bbc30d',
      'native_key' => 40,
      'filename' => 'modAction/9831774ed04bac0d62a2739145c91f67.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '1d4d7013f9e520b82f850a0a09dc8e7c',
      'native_key' => 41,
      'filename' => 'modAction/237da5973f871451d926a8edb5df4e5f.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'a514224d43f0e1db355efd9013a8e485',
      'native_key' => 43,
      'filename' => 'modAction/9e7a9b6f451b2e794265a6123d0c3d6f.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '33c69b4c1b7ba00022d12ae83a239488',
      'native_key' => 46,
      'filename' => 'modAction/695e6e15d39fb613ff87668871ccc772.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '0cf2d3f97f2c1744ebf1cdfc8bf5bbad',
      'native_key' => 50,
      'filename' => 'modAction/942e466899d1ff042ef1f5750f0aaa78.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '9341719bf6dc56465a9499d9bd603cf8',
      'native_key' => 54,
      'filename' => 'modAction/cd1910809628bd0e17d6c4dac60b8213.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'd8fd3ad7118fd824217e6309eef8ad6f',
      'native_key' => 55,
      'filename' => 'modAction/06b5c13b7e87574f0b3486ad4cf465aa.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '54908cf1607863cbac1d0eff3e2fb1a8',
      'native_key' => 56,
      'filename' => 'modAction/e2d4231c3ceddc0d7688c8872bfe6428.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'b804ae368317b453b17c76ae917c57dc',
      'native_key' => 62,
      'filename' => 'modAction/c510052b3ef31208b93890aa87a1077d.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '5b8cbd43abbbc0ef212d9ba399a11c98',
      'native_key' => 64,
      'filename' => 'modAction/c33a5f96dc164b7f592136af7fdd8739.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '419e1d392336e81dfc110e9a66eedc77',
      'native_key' => 67,
      'filename' => 'modAction/8b7385d5d96a65141629debf08171044.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'ce412ae09e2219e39508e96130f8c905',
      'native_key' => 70,
      'filename' => 'modAction/9e22f2463f26e473bfd319ce8d388c05.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'c3b6688cb4a06169a326a8ac129a3514',
      'native_key' => 71,
      'filename' => 'modAction/90899e8fa2bf6df17e6af903cff25a3b.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '2c51d4d4121276913adf64fd815eab54',
      'native_key' => 75,
      'filename' => 'modAction/f0d793c1a6edcdda2d03271c6ace160f.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'd2cfee6d8aab9cab1c10beef7b7630a5',
      'native_key' => 82,
      'filename' => 'modAction/c4e927c51d114bc02e33b5bdbd16f774.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'd956805fe29a72cb9900fb4e4a40f9ee',
      'native_key' => 83,
      'filename' => 'modAction/b5fbdb239c355001e609ed921395bd43.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '29863edd66b48b7ad8c8f57665409969',
      'native_key' => 84,
      'filename' => 'modAction/9087371f1bfece08cceff7a0c9b23a58.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '3b78c8c37fd734db7fd93085f71c49ed',
      'native_key' => 85,
      'filename' => 'modAction/a782035aaa0bf21eb151a8ad09223174.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '99455f646a8328d0dcefd7b8b9b99d87',
      'native_key' => 'site',
      'filename' => 'modMenu/1c360123bff3b68b025ed621d3938b1d.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'd5c50cc2d22a009b32586f9aac01d26c',
      'native_key' => 'components',
      'filename' => 'modMenu/4aaed8d3ff7d7724449ba0d40c95818d.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'fc4d05bcbfc4e6dde27ed9a4a1e9bc67',
      'native_key' => 'security',
      'filename' => 'modMenu/28061e262480daf6cf697ebb6dd87fdf.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '11667d7c7bc40c8d03258fc72f87b883',
      'native_key' => 'tools',
      'filename' => 'modMenu/8bd93eb32e7f7213777a2ef9e7891a23.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'c7fc0e8afcd336442f40d38066d9b10a',
      'native_key' => 'reports',
      'filename' => 'modMenu/52a7491ac8499f9d4f1daa12ba0f9401.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'b23128fd3724f6aec63bd2d9e5915be1',
      'native_key' => 'system',
      'filename' => 'modMenu/6b883c5538d3ea810ee9107b1d55c97b.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '722b9c3968db9b4d4b641741bca3fe2d',
      'native_key' => 'user',
      'filename' => 'modMenu/ee55ef474fc47d1a3494f4ba1112b1a8.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'bab887a50325d0cfb5b3bf0255a5971d',
      'native_key' => 'support',
      'filename' => 'modMenu/8449a740643319031f216001485b4d00.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'c54b2c3b3ff353643b2b054c4224b676',
      'native_key' => 1,
      'filename' => 'modContentType/8130a8d9bc0552f685d7cefad417a88a.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'e4d2a8aaec4162f67fc59471514873c7',
      'native_key' => 2,
      'filename' => 'modContentType/662d6b977975dfbaf6d791b4c8135b2d.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'b5d9cf89508cd05f74eebecef92dfe04',
      'native_key' => 3,
      'filename' => 'modContentType/f6aabe029a02d2adb06e699f9071e402.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '60e84f352e1176c5d16bccff44fd76a1',
      'native_key' => 4,
      'filename' => 'modContentType/d3635e086b7e2540d43d805d9362a6c6.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '6581bbb722cdd647d57e709b262db9c5',
      'native_key' => 5,
      'filename' => 'modContentType/4bc2e8e2980cd48ca174dd1a9cc19d8e.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '74d8c9c5569cbe3bb8c5c4cdca6627e3',
      'native_key' => 6,
      'filename' => 'modContentType/7a8596bb42a3f848f45cc15a5ece0ad4.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '9397751b5c0637ed87b632590506983a',
      'native_key' => NULL,
      'filename' => 'modClassMap/b26cacba36f8d807817de50592af68d2.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '0d77dab40a05cd1eb1a476b0d798823b',
      'native_key' => NULL,
      'filename' => 'modClassMap/d1b96b7f00c3ed0d5c86862c57056fb0.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'bd0a670c4ed55ee4b82da820d0d64996',
      'native_key' => NULL,
      'filename' => 'modClassMap/1e0d709ae4ad81c00896d1f50e368056.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'b02234f76341a45717ae54b41ce485cc',
      'native_key' => NULL,
      'filename' => 'modClassMap/df3944a4d7fe0880dc49de6899d8a2a0.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'c1297c524ee5553de3ddc28e8f89d017',
      'native_key' => NULL,
      'filename' => 'modClassMap/d4c360da1abfb88fb89d79a204458a33.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '667983ef847654e99a3593f59a1a607c',
      'native_key' => NULL,
      'filename' => 'modClassMap/dc57d026538c47929679294d6d313ff5.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '1830e5f74ac0266c224de9bf01087117',
      'native_key' => NULL,
      'filename' => 'modClassMap/8f5e5eb2d44a917ac41c95b2974a44d4.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'ae0ce058d79367be5b11f5dc38a297b6',
      'native_key' => NULL,
      'filename' => 'modClassMap/ffda173f976af9426839d28919179308.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '13ffd1bab3b3edb506f78eda86733367',
      'native_key' => NULL,
      'filename' => 'modClassMap/7dbf7fa61bdd837af816d622d2fe3916.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ff6663376d13930ce980f8896e476260',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/e8df0ab2f05085274fa1d44cec3f5564.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'abdc735e43748dd04a50bf1837464ee4',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/bab97b1a2e77a07a56cfa9047c8a8fcf.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9130693eecae2603e51c5555fa89ae03',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/5a10338780c93ab9bdc5405e0d5bc1af.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '798caf22654327fe76584d7b9de44cbe',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/00a9c4bdbe85d57298e1b4e60dec8370.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '15841fb6fea002a21bcbf8c415cf1047',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/8a599c7f57fdcb6e052a0b3fa172cded.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1b55699a1742d540635c7ba8adccb78a',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/9bf395369477aa9390274bc7b2bd8b27.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2014f65fcbad3811488584c27ac0994e',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/ef0c29704ff7f07f3d74813adbe2f025.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f73ba8790fdbdb7b46f35d335b4c3441',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/69fef1298905c0ac652e195e8261a91d.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ee397017a8b0e590cdb75b3816d3df85',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/07e2f8ae97457dffe2efa1f2842a634b.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '384326d9149df9c271184847747efbe5',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/c74287c363b9416bfab89dfcd4e57acb.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a4d45cc7dc7619162ea1aab687b431ac',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/4c3da65b693ea22aaf8396d1e5705e9c.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7fabf2b311ed40e37be71041e44c2ad1',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/71d7e24cf7d59074480d75ac2de86d90.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5bc552319a538d058d45be1bd2936c67',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/08c2f8b57f57f28e13b82f4c73ba1b36.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7740693d2d89e130ef2b3f76589415c5',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/d2ef860800136732dd9a30ae367a669f.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a4d0314a31c4b4050acee0b2ea28c522',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/09d70ea46108e3ab1c948b41b5b90f84.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ffadf280c838c5ad3e0a5dd154d2d1f8',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/1990153d4ecbf96e0f7b1cf208432f20.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4e3be1fdc7ce421631a38f32ab595815',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/5bf2f40d420d527a5231ee72b0d52f2f.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cb48b115ebb0682661a5d6b81bf246f1',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/38533aa8966a2529ccb213519166c4de.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'de25658df0c3e7cf439c991e4317c79a',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/7a33c81fdd0ff5e9011f31a31b25e4c6.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'deb73272656a1e62a42b0a0efc7dda36',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/f51e157a5288fb2a8a2f67d8d43e6c97.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a26053a75a3ff0a7edb9b974943344c2',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/e48498547e5aec38622bc75bf55705d3.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fdf2a259307562824d7cc8ffbfab8b51',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/b697fbbeafb0da5402420212b2a86923.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7d2f67ca1bde99b9c1e280701292707b',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/d24fb5d777ba0ff10e2b5bd0df7ba131.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dbf44742ac54141409c4afc54e95e525',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/812eb77ec7c3fdd8f00854e202581a2b.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b9c6ccb11bed3473538da06f15df0bf0',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/9e207b2c0fbd91350a61bed3810b0d7f.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '56791bd2af9ba781dc18957bdf118533',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/598181cb4e849cf0d0490e348d53a441.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3eb1eb9df4b7e8341b3961b5c54ca746',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/e0b4e354efc5479e265008cee5abf742.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5b27dbc4dd7008e23631281b9fc2456b',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/7d52ce5f9b004dfb86120b5bb4e955a0.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0ef2db38dc0addf16c16d03bebbb64fb',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/aa6119590b1b1e67f6c56237f9ad6022.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd72bbea463b8070ab2edb51e1d2669f6',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/a672ae869100c220db7c9f154d4a9c1e.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1f98178c32a6d7ab9a55134b6d3f352d',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/89ac562b5902d7aa94ec582eaa67280d.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '423d1468b1c3717a5f9ceaa702fe064f',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/0fa68483f94ff396b42131de73904646.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b9e82067ae02d3a36d68cdafa5993849',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/12070262c4abaf58392b570175a3a701.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5dd6e377aec47737805f471419ab9a64',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/109adfd534639e9d47241d0211638527.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dc3169760cb19aa8b2c23e5f57a6ccd8',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/aeea950aa13a4975cf82fea25c8851b8.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8be616836e5462ffaec30d89fb7c15fa',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/bd037ff38c7586035a0e2b2edcda772f.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bc92de826c530d1330384a5ac12860e1',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/58fb768a926a3939ab6e8137fd66e08a.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '87d15a6af4cf9433530587086cb3d198',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/c38ae43bef88323bdeeef0bb7d982299.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ba95908841029e4bc264eb331dee71dc',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/05ca3234a0b2873719ddfcfcf4e67721.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a2844f8b42cca3fab9cbfd51c2568d87',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/74b2ff712c47b2b572dc3bac09fd4d51.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6c90e9e974f08a9528dd587712da74d5',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/b75a9f3397ce09b5537e398f190a8da8.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e799b4809f1f5052f8a17483170adc67',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/e7fbbc64be6093ab56253fbbeb2b7857.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5e5adab113004fb953ea4f836bebe3c9',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/b8126e97e3618f18fe90aca8048e82d9.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b14ab1afa9f552be41d45b837b1fb243',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/cc14cd9bed13baa622d2ff0f832e5529.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ab5e19164e0f7d70fe67bfe9cfe2ade6',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/2d5d1bee952987a9f7864a7356b44595.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c4843d3c14b9340edda09c07dd937fb8',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/667fbc83a7b10184f770c26905a7725b.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '991846811fdf0dd016f047ec17d22baa',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/b80ae39d8ed384e6a98a2d6029fcd768.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2a2101f6dd09af9349eb695e896c5300',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/bee4839cbea2a1aea35205ff072aac2c.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5b088b78cddbb318ece8d2fcc2885907',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/1b4324fcf8235268c798646a8c2704a6.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '75566a97f6376341703327e4979354bb',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/101cf837a0316c0a46ee82f687930bf0.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7c4058f74b837a72c54693449f017d5e',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/d90f71a1e4e53048c754d72133201212.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5044b41128a141a23a7e681ee52f36ec',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/ae0063ea0e7d6af42b1b00308280dbb0.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cd74f71d87f44c4029887991b495ceab',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/f75cba4f310270a0dcfb1deb4d9a808b.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8fa1e173d43efa1713663dee06bbb7f7',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/95486f9c36068dcd6f14d19777517e71.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8b2f26735b5075a53e18194f31a65ff7',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/326e454f95383edccc0c78271e16fe32.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f08a92691cf8d8f4232efbd9db13c0ef',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/2c15803ef1f55cd41b719b8b73f6568a.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a40ffdb607221ff994d5792a7a596dea',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/def83908116360d1bc75cd1a9de32dc9.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5c52ed71c7dbafb29c0f40a0643683a3',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/2fd0dbf91356132d51469f2dab5929be.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '18c6058d6b05a3897035a650906487cd',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/3cb64b7c68f1fc5ee920ec4e048fb7f9.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e7f521abc5b6fdeb0cb9537893d0d976',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/f492d2d80e14950bf9e5d61b970f4532.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '09cfbc372a72f83eb10b00563b54786f',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/f337b56b7f2451661a58282d5e08439b.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '011cf6dd87dfbbae2a3c07cad7237f00',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/813d8df03b9914b08594ecbcc8913eb5.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '28bd6e1ed56635e8b8726d8bc50e1791',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/ceed1cd1f0298f2911a57733a5cab732.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '19e9f410ed92632c2ba5def5f3d486d5',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/0dbde6c698e69d5ce72bc669f492ae97.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f01cdc93c6759d8f6c8bd58d5ba027f0',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/ec7f2cbadf93f42be17b9bb7d29d3d9f.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '51f7d7dc0f1e8f5af10f2e72275d12fd',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/75e1c3e4a8a41a9022b8225cac25e545.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '50abcf2262bd6abe45f6bb4d6d0ddcc6',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/d20c98c506a8ab289c05485b1051be82.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a98fe578d94b2c8c91cc3887c3e16229',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/1b23d484fec4f303e6452b0955c1be47.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '53f59aa4e283defb0cbbcb432bac8c82',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/c6660d06dedabe2d74fd252c0c21cbe1.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9920a6116f6b0f9c3fc558c6e03930cb',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/0c0d21794bd4a2629d40b01eea75bbdb.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'db30bedbfe6753c79ae8dafa64c9738c',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/663669ca4283f88644c00fcb3cb35728.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4522fa1986e7e0453e0339c9338d70a2',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/b6c0d3cc4fdf28d2d29287402cb604e7.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '43a0c1145464d2c0443d06bc538d3137',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/55d823751bfed0d0aef09e496be40d07.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e68c94c1aabf580e80c28192387489f7',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/8b7d3fa9a026e244417d7ab61c385706.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b54884542b7d90b5567e65490798ff57',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/b0b7a023d4157e4d6af46146a237b38c.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dd6187fa9c7000471c6eb443cfac7a96',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/2f1b2219d18cb3f050536c3ed582c307.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '550541462f296bf889d572bbe1425255',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/f2c2b890b990d162f2d7411c0898789a.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '47ca870860035c08c501dc1657f4029d',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/5e77d8333348920cc663a9b848c84609.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dd01044c151a151ec05d07e8116a3d02',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/430f1a739b30287aba42c9ba74d4cdee.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a6be96acc8b80d821e6bf2ecb4673b47',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/fd14dd8017e896a870e12ca623fcf4a0.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '87e1a8e9ef5fd3a6891dde60a5662e20',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/ea18ecbdfb1d13041c7dba9121412691.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c59e34b694dc297f9a848cb00a14515f',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/ab72d57959ec599ae424fd0172e49727.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4260bb908f39388fbe6c9502cc41372f',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/e6846e66aaf0a97892b4d72312eb7376.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6e07ad01529dc46fba9ee920681b3599',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/d544f6e2c4944cfb07957eaa07fe61ff.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd790031e9b27d4b03ff9c7437a123531',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/774930a1190afe58c4075a5f6de9c9ec.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3b252a031e0625bcda94bb0f7f4a059b',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/46ad5c19ff012a714c78800c915a258f.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b42ff7042108315559d2b06df7906f35',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/1e45e4b2196dfb3dee504cbfd17e85ff.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '64bee21ed7085779dbfb5de558ad1b86',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/e005493703d8a8eeb77ca59f27fd61c3.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f28965fe06fc3d906f7244f960e9b1dc',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/6a8d2780c6e3906b8da9c1bfeca6a41a.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1351afe20a91c274c9ee92eed2047d55',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/56d2189eaa610640ec3bb10ce33911c2.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a30f9dff8cdfed6ea15058f65d314af6',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/06b48569923b1054c7bea35feebf7325.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f1ec5eaf3d2fe9e45aa404a2c25e7808',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/53ad91318a8d7c7316b2dc6117754ac7.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e4309395239fe803459c9c2f72e439a1',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/016d8466c57dfb33d04994304e3a28e2.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '77286eaced8a0343a4e48cddd46cd2e8',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/48f5f479b84574953b50907c0213e31f.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ed9e2dd4e01ac74ce557792f2aad8e3d',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/84492b8a4c60c1ddeb2e8a401db9131b.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '74546a08d08b2edac31e7687f38bcbba',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/3d1ad60d1a33fbbf7117de7eae71115e.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '02bc43acb01960dc6eda2cc3db466afa',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/2110602d7d0d4ddc6d33c9c20c1bbb37.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f2c1ba152c8ac6de74e71115dcedb813',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/90f7efd90e4526985423a3d3f5534c20.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0b27146d85e3697ae46f256c3b774e58',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/5236ff539bba126127116615fbec2937.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9beff9a3e78ab2c8daf3d37be6455ad0',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/843008e93a72864abf0b445ce6d0c0ce.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b518d62c70186c90ab63cd920958b113',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/e6390664ae473df139c46e9f6f3d7b52.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd07c1720e977a24b02ce5ddd5d22138e',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/d47be782ebf09aa74fdd24ae32fadd26.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd147a3aa112887c36e8c60a4e5f730f1',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/9ca01d4e136f11cbf7aa401affae2767.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c64816f1dd7d6eda18d8399131d73a23',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/ac2f1d2f3ab9a4e364ae3ecf23d59e74.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a02201346246ff25cd309910855aed7a',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/e41a4e88d2192c72781d793516382c54.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '46616b6cdff25e50943a2c212cc1e5dc',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/f520ccf6f1229bdcecf3d9b4302edeb3.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dda5743f371a300b81f08fa38203c65e',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/08b7b10cb81af89cdfd0e2037fda11c9.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9945ac3125a913620ef3ec417417f058',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/b93e7ffdcf35a9d1ca4772ccc7412ba8.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '02a99541d224735d0f50b50d6e8d4e16',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/3b8aecce11942bb3ece27aa11772a0e6.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd399379d5076db338703265ffed3f4ad',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/46782b9b0f96d3281b18f8ba9976acf0.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3bd6c9aa25ceba8c58da447299d7e5b4',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/6888ff6f6bba2d35b71c7483420eb4b4.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e1a915d089a2c08e15c3f7bdbe9e2df4',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/77a420672299d22a5ac0c9bf729816e2.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c56c6b15c0688b1578cc0c9b0cc22a34',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/28f6588c44411b66d8e05300a5f44e23.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ba4beb5fa7cabd0c6926699e2a26d8bb',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/a8550715a6e82516571198e3c478da52.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '100bd09276c3f66d4bc9980c5a900ad9',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/f20ddc3f617c3b5e247209f5aae66ab9.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '02f52b61b2df12b4c768a82b4af7886e',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/1e2a25e2a0e32e7b6c7803664472e78b.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3abad06bf3bf5d5e3679c028790cfb1c',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/2196b9452fbcf3bcba5a9d53c65d181d.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8394bc34a13bb36b2e72df538c0a8aef',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/0e664815fd3cf3dc7b5cf70c4a51e411.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'efb4be23c71ad1534945a0a04275ea67',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/fb87e629262e9acd22b8cee77dde8dc9.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1f4248955866c717dedfc3949b22380b',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/087c3987801960e4bfec819f76aefbea.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2761e3e05a183be2c8a000d02dd99080',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/d076f723491b06ba5d0c6ed2fa6073fb.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7f1283ea8b5c9b02b4615337721f354c',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/ae8a457ff1cf92a619d6d1f3a9ed6a7c.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '08453e8ae99af0510673472ab5b3fd19',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/ab586e06445caff3c546b4e102f47a4f.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1b354bc13107fc381c71695f84030ee6',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/cd390b71384743219038870154062581.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '739df9540d844a8060a15924ea7c6d52',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/e02d81197b8fe931e1e63cb81382a4d0.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '195831865d92ce5321668fbfc0893a38',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/53aa5b66a572e468c570a372b84584d9.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '508e97befb1adbafa8df8e4de037eda6',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/a8936f9f2cb5e44d410b3b9adfc0acbf.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a43948a47b4de124943f638ec81b22ea',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/ab3c6b4c614ff4145b43dafe7c2ae7b5.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '89dc5907c5387957a6900ea5eebe981a',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/cb75c88cbd37d3d6ec2fc0b822a02d88.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '37cab38d9ec797e57212f5460adee78c',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/6eb3f96624e47158c847bb599295ea9b.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '61ab7dab44c80b536c55b78fe2be610e',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/f84b1bc3ea245b8ee6b2b48bef3ffadb.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '093adffd48092b101c2c3006dda0d05c',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/7534d17a68e667de8920c91880e91bf4.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dc7c9ebef542b6dc83c8a15a68e59456',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/b5eabe970bdbea8abbe0e042a4ac886c.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cbc6a67cba110bdfe9af7d9284d66f4b',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/1da4e9ebfaa6477dc14906b594c81a6a.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '60ae5ef24f6fde50f196be5a5bc5bd70',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/f068a8fbb4acd1d01a8503cacd3940df.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '89659c51a35318a1a824aa5183d8ffa3',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/bf43a50d419616faf0f1f538216c35ec.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '709d43bde920448f12cac3b79523f1dd',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/f5acd9fd1a0be9ef3313e014251a58e6.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd1e9df4d84daa786324cc8186e00e8cb',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/1faa4dd75138ffe7078e86958e74353a.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '31753070a475763679bc37710e8858bc',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/26e796dbcca560f2d454347da4a9d18a.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd39bf7812eff0356e9f2d0f422b8fa14',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/992a1b3bfa79d1ca462e929bb5c5b91f.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'afdd0a040c5bbbee51c8388d73c6224b',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/c11277b31df872bceb9ef3accc2f1e7f.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e01a0b3efbb81ab67faa91f9e58d97cc',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/66d1b855c3706ca751e476245deb7425.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cdce91c393adbace4c04ed717260796b',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/70ec5839f7371a8fd8a078b5650285c9.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '48e7bdec95e57facb9244494c86654c5',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/e082b37cffca167b8a70f892b872b7aa.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8251979f7d6cfdbe4f1e0a0e1b8476ec',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/fde69ecf295748194b85efaafbf51397.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5e77e80e9e11cde2bdcbaa533e71ebfe',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/bb5c3bb59a53ad5d40acd2bf5fdf1226.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ccaa52e1df82af96493ee9f87cdd301c',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/66f1339914d3e660fbd71219a9fb551e.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '47bdfa4a6aff4dc64920fed5df891215',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/5e4b8882dfe3348de67d8667da98f853.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '64c42b0d03a90c6a96b931a9fb9550bf',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/37d8c06c2f5f3587c95d5e034d17bf8d.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a669ca92d2ba178814b2cdfcd4feb14e',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/8efb23e15ea08a184550894751ca6141.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd5dbc2f65eb9e16d05b94f55965789df',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/fe2c68058ad138b360a26792fb7dc604.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'df73b12d3a54cfa3165f75d5e1e6f2de',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/5abee522c1ce7a5df04bf9f5e351ccff.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7e83f29e3f2dede400f161313b57ca9c',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/07ed90af51d739c97341acbeae1c4a4b.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'df06bc12774d1df2384a409457d37021',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/47830f3594ce5800a3a9973567134400.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b3148d855d88d5244e6b775da291ebde',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/9600423d7f1486bcec0fedd439c92bbe.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a8da52e71022080766d5eadb46ac472d',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/ab1bd02f7951d55854c71eb02cb75f18.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd189139c7e3e7289bfc502af390b29ba',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/883cf704cc843f76d406786cb0878c35.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9cfb7d890601ace3d8a591d2950fe527',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/d3b064ed94f5ce7baf89b941eed8029c.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea9764211b20910c29d20117c1c7772c',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/e91e10b57fe01db160b858df1dc3c881.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02cb839e262da21a845e8168d61aeb13',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/e8c4c273c6a09f141c33b9758bdc84a0.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e67b655af9a27bcce0a151d8548fadde',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/cba48795949ffc57d5dd40cd907d9eb9.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ee9ae0b2fe577c7d0a086399c70d669',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/a3904eba2670f73732804dd8a7779b1f.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '61e6372f90508cff168ae81ac5f2d6bd',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/14ec832a83b7422a225bc5da9fd46d03.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b09dbad4f2609664f5bde627c451852',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/ff48ee191f0876459c722d6ef0d79845.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3fe5acb0171dd6627ca8ad2ab903f512',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/6923e4c0238a12a8716b45e34d11d321.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a1b402499cb9cc957d410e8ecc82f81',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/dc0c4176cd224e980bcc1ae0b1ab09f3.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3b4a4799189c5702f080c39ad42aca67',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/d39682be3f84b717673c850cfa6e4d92.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a68b8c7cd7a29d4374af4111f474d08',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/918d19aca0e0b77cb71a79143243563c.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5df702e7b917286b2c6c4281cd31cfbd',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/a023ef0d1fd0a2d512364210e407eb43.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e8ef891cd42108cbf1f32177cc29bf6b',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/d5f42e380070bbf18ffb0f7f2d0e8a65.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '693399b423cbda23b22eb47a74378b69',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/5c7b829fb102408337836647705985e5.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ae8a8e95a474250bef92b7bb34c5fb3',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/af8c65a79e4e4b15e5bb18699d63f07a.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0bdc0ac461b8f268c6eb57f7a419cd60',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/ab9b03f1324a7876b7b1fe947779dfcf.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2051f913b4eebcb9c3ca2f04aafde613',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/362fecfc5f1f2c8514e5ffddb791af67.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6b0f25669b348db17ca94919dcf323dd',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/0bdeca2273454744de52adb9089a85c5.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f4cd2f6d142619d2acfd78ac89211c9',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/beb6f8a82d433c8eb548c11a93d1c93c.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '455834c36c7cc52479c9dba1b231eb9a',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/a1dfca846e88031a05e54b40d54a8207.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3271b09e2ae17eeb8d42f4920d9d2fa0',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/154bdfa35bf5dcec8300ac3b9561bc56.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ab9e6c910902457ce2007fad946ccb0',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/0b701859cfdfd5392fcc7000739f573e.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '523c401492d8e86feb8f1a268ceca18c',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/cd2226c47d4d6a290de9a3b757faac77.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91316cf4f4d47966809dda46a34d5797',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/90bf67d22b8289913744b5ebe77e67e4.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a707193b76d097869703249856b436af',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/628c0d16d3ac6c8b91cc38a3615f7a1c.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9f1d21d32418aa89566ffcbede48cb6',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/7ab8052a070b88132e381441e7954219.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c118d0a447e91125b64503a3a6ea942',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/df102d19b1cae4ce382208be28547e8a.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '45f64c075cb691d06fb3e6c67a6f034a',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/26b30f25f49ed01b091867f5ee1820cf.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '302cb1a9ca61f796430e0442fc8b9aa7',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/54b9cf439306e1606bd58ceb237ee284.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d34be647b83e6ac5137cb9ba7feced0',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/973e2ce1c4136439addb0c7f1f07102f.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54be195ad6e8c96114f37d17aa4e04eb',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/1aa7a5eacbfd419ea39b6282bad07abb.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '95e45f64f49bcc33be49c77e26bea07e',
      'native_key' => 'concat_js',
      'filename' => 'modSystemSetting/ae7d901871943476bd5a8e1273ce9b77.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c719f168328bf14d4065f5e07231320',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/3e3706a2bc8e22312c467d5a0c3391d2.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'afe1ebf581bb1f6d5083b5b9670b238a',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/52456c51bab6432171712ec724601ef4.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '935c71e4f5c50fc3d465bc49c94ec4ef',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/5ef2f6e41121122f42f2051c87a47772.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '526511ad5a4eadabd743c6f7efc6bb2d',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/9a7efca6f351400b5552863af0657a48.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c1ead0f12de71d7ebe7324f1a281f78',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/14b5ea70a6a66e7d1d37320f24ac081e.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd22ce60d03c752a84390714a41d5a69b',
      'native_key' => 'custom_resource_classes',
      'filename' => 'modSystemSetting/c7ebca074120f94ddbf82984725b2b09.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20365899d232c803dbd96702d8c22b51',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/e5dfd1bb1b0ba3b270930507d52f275b.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c69ab8cb25c196846e317212c89833e3',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/670b0bac292fb705ead5bad3f1562600.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7df62bbf7cec914258363b7f2623a2f',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/b177e89f0ab75c08e1025f0c655f9ae6.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '333450636e012a5bc0bf1e889b132b46',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/c89442639e0b1bbc79524509e6c08d35.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8223e179c55db102034bc2582ba7d9b9',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/d9b6b8df89c987335f60656b20cc2de3.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '519fbb30c6e29d2b361da0b23f4a8bf9',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/0d835e77033ab58430f07684e6f7923e.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '90249e89077e2a5580e60bb8a963a6ae',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/0ef4a2834535804d29f12e2ad98cb196.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '460eca776e321047f3737df27d4a6919',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/563c540ff3b4e40fd23b46b54afbed7a.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ebf235b567eb07803036d5c1d77e8e20',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/f5b2229b920adac650a21da7c7a0761f.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2872939b91dc868369c19e83057b452f',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/6042b35b36119661c73ef3866fe8a2a7.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f30bfb4cc71424deec4d0abaf734212',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/f29ccb0a8b6552cc2c4ae63ee43fd8d0.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '131128cb9f4686af5784007a9616154f',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/302350d622fc4f4a6222dc445074a2be.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cfe66132e9089cfdc5b369faf5ffd3b8',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/e0ace36258f675bca3871864d54bccf5.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a3acf155680f3d186213396dec574f5c',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/8946609793ea5281fa8297e1150cf70e.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5925060a29ac6c82a77bed80878051f4',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/5de6881c3b38862385ae7f4f6f8216f8.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d19c70d3731132d6ecc2102d4242d38',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/ce995c1985e7eb7303d92795c47e94a6.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43d2bc9053de8ddabd642b78ed91effa',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/0a017369a4c33b07c793f9aff1368ff3.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '850aa6a8f60b510c5cba44322c81b125',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/9b8edeea63e1db9e1846fb4922b0485b.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dbbee80b1fd94c1ceabae8dbead9408f',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/a0391e8a337ddf16f7c5d302e36264aa.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '72d364ba73e1515a0f5e8b68c64b939d',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/590cf7bca29762e210c048c90b87b94c.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5bae7ce562461c761f252eb19e9f6380',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/b82745d59fbd34906449f56161258ad8.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64f0a311949de4db25751e13615cf2cc',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/e76c9e4d68bc76a5e09b6169cd0ac727.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8014d088baa0a78ad36f42b64fe12a2e',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/98e34fb5afc067e3ff1c5bf03c3aeee6.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd97ec915c9223ecc85f1a5c5dfbb5ce',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/a4f5937a848e6c741aba66b40b1bbc59.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f739593aac7012779eb0d98ba9b8f669',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/90601772825b1016a3a3290dd5eb064b.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f883ce669e147843e1896c4d380bd15e',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/5f12b96022512aeac5f9ff412f1cc502.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '340586009a675c00651b23405e5dd4bc',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/dc8b48d2bca59ffa3c8c17ba810d8ea3.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af8df9afc8c059d80fdc81df94fc0dc0',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/6ce22531bf8180bf5589bf20c3dbe3eb.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '26fbe53e019fc66a6653298305daded8',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/2ca808abe9948e23fca0900b330e15c3.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '55bc253c9e3ab092105f44e0227c8ad2',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/7d8befd846c4e36ad1531835d066f373.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '462b4649c79927ce3916176ad300ade3',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/151c2c6ce3ed6de888362b7f4a88d1d1.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7e975aff0ccf444162fa74c9f18d009',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/2dbf43005e6171271855e11023e8d9df.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8abc20889053d787925f0c2be11bb4bb',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/2216f3a91b778da16b8879f379d5510b.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88dc7e2d730896606351e25b0788d0ed',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/76adc515354e45e8f4e59f6302233dc0.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e5bad03430c2fd614f295aeaadfe2639',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/f2b4e9c231cc52247b1693e1a5300b43.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f30c90d6f92b87921eaba75bfb39fbbb',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/4d6840410ccf729b24b4346f008cb37d.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b2062199a62a81b6e3131b516a19a7b',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/652e67c2248c92d671a2c8c0a859d607.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed2536ab40f763bbb9fb7eb59eb60cff',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/3109ceca5502cb8a0e61458719fef710.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f5bc1ae29c0ec09131424f76e9ca6d3e',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/537cd14d691854e8bd955ee88bfe3e2e.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b9d2ef29d9e888fa12c943f7ac5b824',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/781fac5c328ca63a0bbf9349be8b3608.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '596b0a1c9aabf33b3a233bd137cf0c0c',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/ea61f0b04036ec078bde486181681037.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fd47b73e425f034530df650bfabd1240',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/d34a54dd3e1629462fc0d31a0ad3679c.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd823fc0f18af75dfdb9441588fa6354f',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/0f5b63ce30ebd793e397f7980b9089c3.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '918a7f42c80568e6195261afb0ce28ac',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/007a40023ab411b666e869b02bcf2778.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6ea7e34e6999ef9d783a71722e28af3d',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/8899dc72069d6e010f6f6a436e22c0f9.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dbd2c6bf8b4fe01ea74843978736b67b',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/94f87f8afa926449f775b1d7093f03fe.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c62e6a7ce1a85f3a007f5363108c44b',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/11de1baae705331a043900049484d6c4.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '387e526589c5dd7bab74959337b70559',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/630f037e8596ec9ca3e7ffe9e67d7a85.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e12812866f378b15de66a15c9c7d2871',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/d21cd42f7e8d292ada59feddeaaebaef.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6ba118f51817bf706fb223b99c19d55',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/cc7036c34b08807688792e8e70a41449.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '218c8a55f38a4f11f7173691dee625c1',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/4f5f4ec621e627bafe04fd8603550194.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46bbfa21b0d090dac3889ecddfd6ee2b',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/670676264abcc1af40435a761f016a2b.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d8658347c308fb57fe64e6b488a32a8',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/5c23b3bbb2dedf914f42e5ab4b4f3a64.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd9dbf0efb980e63808341013864262e5',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/137b4637c75181b031abf5f3e7c9a7b2.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd245ada4615517f66becfabbbf3dd5e9',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/e3a86b533907588c0ebb03e43faf6abe.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f02c56a710f30508068fe197f8cccc7b',
      'native_key' => 'manager_use_tabs',
      'filename' => 'modSystemSetting/2abb834d0ee04de58bde1494f871a2b0.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eb539f50300c3b61192883cb083535f6',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/949372d012ac6caa765156c76d9bdaad.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '04f41eab426d521d47afd3d71cf1dac4',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/5b8d545959874b1976d0d7333b245aa4.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd535d67d23d5838ee0dbd77366749103',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/2b64e39c8f9ca0ef46cb9371aae53ac6.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6faa3a7c49477effd40183ffb8f71ad4',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/9cc234f9e342a36f25b9c4e02c2a3299.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '397a836ff037be20db346eadb1dc2974',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/30c1b6ab06a75c4045bf065f39505b40.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab8e1af2938e898e546914a11d9e0394',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/f9331ca0bf00d1084d4161a7f95e2288.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9435aff76511d0dbe51e533eb28988b',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/05cae25b4836deeba90b2413b6225a4e.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '19d3d55958655acbb8eb7cf43efcb88c',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/6e6b64217eeb1fcfb897d6415d933ad4.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd84298671ed8270b7bb32d44935f462f',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/3b7759f663ebf16b18f21a623e3172a3.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '349c88941938ed825d1f5593a699f03a',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/671d0908c330943c719374d244b285e0.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe8d8f7f2c11107a1c778af76b96c475',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/fc9743462049190c6f5aad655e1a2373.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '49748d7c869ed719265c7cf3af30abb5',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/183bea513eb1f4ea296c1691d6a33221.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee88e8fadc63c8e87e405dbaec80b77f',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/5574926e1f815e659865a3cd7ce00677.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5522c46eaaef74bc79380e329cea11a2',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/b5dd70d6c051ef55b4ee80458cc62784.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8dd19935a21e0b635152a3777700d3e',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/d1a9cf2b9a7a408449ba7b0521130374.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b89ddd3df06163352c59ab839d1931c1',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/c32d1d89f2cd5760921190b8076db68a.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5fa2c1d7d7b01c575458cd9c0f3126f',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/c98beef6a24e48d236eb0db11f597b35.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '953d12d699178177013af89dfca76228',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/6aff965ddca0d73f30eaf49c23855d92.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3974c8f9e1a6e92809ccaac8b5704db8',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/7c7391360f261b2ad32619085a345540.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02e4e248a7524f9b5006434bc7f4ea3c',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/a948bb893e96a870de0c253a4647948c.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '237141a0bfeaa108950cf3093e7d6182',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/08e29563e3a32cbdbf7112fd9359a8a1.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c831139c4ff548326734f47778384b7',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/6aa236480060bd844d17cc0d5d0f932d.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6d4de5c050c8b3d5d1918184bf2ad33e',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/18b8a2c5bf65f2b8dfea2abef4c4488c.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d8b0af13ed1945126d2faa39befa4e4',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/5f78e7d90b5a655369c6ffea3a5b67b4.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd59cf188b34dc2ce190e7f52b2147873',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/9abe163f6d16099a2e90a07d41d0bb5d.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27168d8ded5435f200db61498281d472',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/3e1863f088ae828ea4a16cd71ffaf9ff.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e4e1debf81be6b9a400e4a566befac80',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/0b4630c199633ca7cfbf03e8ca350ab5.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '948f565d39c52090c2ab65209d7c98b3',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/b4e09f1ccc62cbd952fe21d423d941eb.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f5de2fb539235126e972e7acdb61fbd',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/efc8dd17c4a0d451f43de5cd123b3063.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6f4d9a03b9274282d55572102562d82',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/52cced9b9137917f4ef38c338077a854.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4274ef9de853a1ec73fc73b9de032d7a',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/94212f42871fc65edded3a4172203e10.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '13c2ac6be366a62550b82466eedf87cb',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/024d4ccdc2829283b63d955e9646cef9.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f00c8c49e3e157d26cb1c51a948e9b3',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/c6d6ea50efaebad4c5ad750e59e51b9e.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '84abf495c7967a858749c72b92b990e9',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/43a207462ca23e4724ae5d58566ec5f9.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6857bb12e922db063902847e98b508ef',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/1d5b8e987c77edae024820c3b40182da.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '936fa7d22ba5b5931faf6251ffb97c37',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/002fb675c439a4f5daa402bf3a85f8a6.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '01e5d090e2a52203ac1cf9ae3d5ea7c3',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/8d5a160d42a78ca0e8d90ff4d3b6e3fe.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8c12ce6f34d0bf73b273eb241fc64245',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/1f94e664ef6b132c8c601805857badd1.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c0581c9592b91459ff56183e28eecd4c',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/360b0190541975332153f7b7ebc3013a.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e56aac17aa5bd834f5cfe243ab111b4a',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/588d0744b15bfe1e157f6af3d12642e3.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e507ed8e8810b361f264b0c4e07da005',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/12c49c60bfd20c6644c068c1ead41452.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '818c677e8a676e579af4b4bd3f2cbca8',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/a986bb52e3d2f8b09dd9564392a54c41.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b30d6d66b73e6d8d9190ee42c61ec39e',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/84a25b2263525893e390475744678f02.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0ee6a0a95e2ee9c9cbf3c34e9d1115f',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/c3acbb59d60f7298f9f12663e8f5bae2.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4b357d6fc63ce74c8331a3bb74e2b6e2',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/b64edc956b7facb6b7238fab82c28e65.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c6b8f428cc35422f2d70a0165534b42',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/5d72fe4ffd2baef789fb4f659a77330b.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '77e3d0eafdbda7df1f5233ec183a5ba3',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/9a7e6257a41c33229df726381ae4792e.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '273a2a6788afda09b4b50de58ded1ecc',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/3885af4ea4e5c988a5803d53e76c5667.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd48996844dea39469ae483ad70afeb4d',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/4b4b889e367e315bc319eaa2af8abecb.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82c5b7a4938dba62843812d5b0bbe173',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/ea0f914334ada8c82d7c01c480076238.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a443008e523b438280738b052cb198a',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/bde20c3559c449a34e4fe53fa6c8f51f.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b7a276ebc8c8cbfad45d61428d3739bc',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/6e69f3cf9e04ee99ab57539be37150c0.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a2659f5f712e8b490d641e12f346ee59',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/e38f82b908247a107a96776f01ac5397.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a299f4882cc264e89ced948a62f89e8',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/35ad738b63a532541d5092e8890fe77d.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '703d0e83b2ca45c4945bc7148457c64c',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/2ca4520ffd9dd177f6ccaff34ae340d9.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '177fd16e4fe41d8a251013ac6aeee1ef',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/637d316e05e3575109b0621547ca435e.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c72c76b89fff1566ad163586d9271bc',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/cfead19f439bfaab94217c0b0fc49ce2.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '095dbff9dff09fad99099fb33efff34b',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/ab65672830dfedc2ed566d682dc3b681.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ca51e65b0c1439ab115271f07a24139',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/cc0c2aa953ea91cd37ff67b6100c7f02.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c10eaa6b704d39460efcfce1da540b5',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/00aaec2b0423025f9ccd2d9198f522d9.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f3bcb8a36ebe4b9e33c5cc3049ff5b98',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/75b6ab47aba9c881e76d84d65cbf43e4.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e2c844dd52cdd32c19bca7eac911e7e6',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/192fdcef89fae7be975daa76f72bc04f.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf85a269ac2cda7de067aba43a45ffe6',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/ef87a3509242b20b0fd1399238c71cb2.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '460665a900bbc647d34d779dbd817c5d',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/7688dba8174dcd90761657835486d5ea.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f446d3c96f994a225caefc2f8fc5a3a',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/7c0f9124a6c80d36d1ef9d42825b0147.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2bf9519890fad1a5afef628ffca4cbd',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/d72da6476c889731a8b63135a6e49d96.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4cbcfae2060ddecee521f3fef3c83be8',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/5836757a6f1a6a7affcb4ab185abfaa8.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5491ba7a94b3da4ba85187f1736e86b2',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/091b3d55120a16a49f90b27a23b14b2d.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51e17d39b42e19098658d368f2e02637',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/1cac598109fe7c04dc86e22bd7cf06e7.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a92e83b714dd1b075d47f696603c8802',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/0a0a2c4f7041a8470e4cc84c51ac07f8.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9dab5b1b98af8bb54f89120f6d0c193',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/fc6e443df71a82b6f906e8c17a2e8398.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c7e315c41480b5450ffcd4a2521c307',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/57a2a832f5ed625198509c5377ef6ee1.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '58d7371c4379d6977e82c8e64d474e1e',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/4ff976e304c8f54efb1e91c531581376.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '995612f4cdb35f2ebf0e0c776e704299',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/912f9387840bfb9aecf830ce69e36e39.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '582dd37e8067ccea9961c43914318598',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/e9a7665be3c12ad2e80100b4e1d75fb6.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bff44dc30cca138628357ebdaf9a85d4',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/33635c2567bbec7e72f3b53e5f20d733.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2d8dacac5cc8481828e5ca4f14d2e24',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/1e614660271e2822d8e60ea9797922e9.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0344c9ec563635cd55cf614d4f6f374',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/837a619f8162fc6d30a9234ec5d9a78d.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd8587e9764988bb6ac2b152945a77927',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/2e2804f220e3798dac1fcd66fec4883e.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a51e04ddc48d3c06fd0e670a87609421',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/ad4e46351aa454ed581d63737176ee22.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b056584d22dd5a48ff95935a732fd06a',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/ae279ad627126ad646fb71cd0acce9c1.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '53cf1557b3c7c9ebd88cf8fa05a4d1b6',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/6032d868b247964df7de5dc6e4fa29b9.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '8d51152fffe83d34ac7b22c7e4aac288',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/374d3f850c9968aa985bde3b60f4c530.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '872662ec57a3f7e54795a41854a7465c',
      'native_key' => 1,
      'filename' => 'modUserGroup/9c1a14b7ab32234cc81722fa1bc64a69.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '63f1e380a9cd848585d0dcb10d1a17b6',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/92592453d0471c89164f62e63972d48e.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '8c0ab16559e3091adb2c33a32fe11db9',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/50d2c9002f19fff1725d9f363ae7246c.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '7d066d80ad0220ef67699511126c0a9b',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/a6a42a3453280dc948be986a07ede4df.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '4fd0254ecc7339974f0af876167e5514',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/c320c45efb3145b4ff9addb1236caaf3.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'f1deba2033f83c066b51fe09e1c600db',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/c6d5d73d49cf1e8267bbbb9d964db965.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'fbbb8797ed6ee253a54f621a7bb20ae3',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/95fda14df7c9b60e03f6577c3363f954.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '4d438b4cfca2da6c9bd11c90ae8fbe61',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/313bfb2baad5fbaec473fb258ef202f8.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'da0f083ac7a978a2744b8626f2fb2bc2',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/f73db9f243c895331c3ab37aee2c8c8b.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '5dce7767622d5a5c8af0ac12943d1d14',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/d447c330d98d39bf0ec7481ea8793f9a.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'b9bd8423ec826f531c59d226b6cbe180',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/6a27b1b33226304b7de5273fdb571d35.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '90f979eaa81f7c823dd323a0a9be8947',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/9ee809e2db11267e2b0c14d37ad181f2.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'c183b876d9e17eef8c9a689ac1b76bfb',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/6d262a913e7e2f236133e611492bd654.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'f32b0c2084dd8be8f19e7c9d048dcb5b',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/9b75a67d3cb79d8a507158940f77b614.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'b19a8fac2a53da64a7236bd2fdadca00',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/cae2bea59eac83bddce71a7b540db546.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'ecf3aaf58bcfa5f4f4222e186a140bdc',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/d6d3e7011d97beb88bd04e82ef1b18a8.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '288af04cc4bf15371597301b8bfe24b5',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/a67cf0ac21b357030890642f2862329a.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '64dab75f38936a0eabe7a9b45f5fcb17',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/0fe41f56643dc49842e8c6309a1e3b1a.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '0e5bab6873782071874bcfb7b22cf5ea',
      'native_key' => 'web',
      'filename' => 'modContext/b8054ce9fbefde4d80b481914607cd68.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => 'c58df47c95166e31819fd26a16e645a5',
      'native_key' => 'mgr',
      'filename' => 'modContext/805f4ea19737602a4e1f947e82a2d344.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '44d5ab927098bdfc875acc6057fecfa4',
      'native_key' => '44d5ab927098bdfc875acc6057fecfa4',
      'filename' => 'xPDOFileVehicle/f14a435424fdc19e9a4a68cf0c60ce75.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '979bba2ee7e70687e13cf0689db755b1',
      'native_key' => '979bba2ee7e70687e13cf0689db755b1',
      'filename' => 'xPDOFileVehicle/e1f3f3d7b61e0db08409fc02df6e1eac.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'bd15e391425a10eeeb57cd574e9fa12c',
      'native_key' => 'bd15e391425a10eeeb57cd574e9fa12c',
      'filename' => 'xPDOFileVehicle/e3e700b6e087405d3e7256f1b4085c1c.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'da7fea4380c35e690c72e0e638e4a992',
      'native_key' => 'da7fea4380c35e690c72e0e638e4a992',
      'filename' => 'xPDOFileVehicle/40be31fc21d9a37d7c1fafd6bedfdc58.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '12a746eb249d2cfe5eae387f6bb2eee3',
      'native_key' => '12a746eb249d2cfe5eae387f6bb2eee3',
      'filename' => 'xPDOFileVehicle/ca1c8b34dceb8460c2ffeb17bebf8669.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '454caaf46c94bc2f1a36fb5205809937',
      'native_key' => '454caaf46c94bc2f1a36fb5205809937',
      'filename' => 'xPDOFileVehicle/d0b9d21cebf20b345f14c4ed0bba831d.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '8f4f4493d2b0ea072298a008e3521257',
      'native_key' => '8f4f4493d2b0ea072298a008e3521257',
      'filename' => 'xPDOFileVehicle/18991be7c58656d386de1efa4cb776eb.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'e4754a5c236a880e2ee857192440d5cb',
      'native_key' => 'e4754a5c236a880e2ee857192440d5cb',
      'filename' => 'xPDOFileVehicle/662dfb84c4afba6712628bb703c36440.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'e0b51424e6481115d389c8067a8d94b4',
      'native_key' => 'e0b51424e6481115d389c8067a8d94b4',
      'filename' => 'xPDOFileVehicle/cdf74be1467e92b2fa327bfa300b13df.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '912b97e1e11ef26d7508fadf3c7e8e81',
      'native_key' => '912b97e1e11ef26d7508fadf3c7e8e81',
      'filename' => 'xPDOFileVehicle/13a56e446ace61f302e5a1209273f8d6.vehicle',
    ),
  ),
);